public class Problema2
{
	public int eliminacionDePalabras(int n, String[] arreglo) {
		// completar este metodo
	}
}