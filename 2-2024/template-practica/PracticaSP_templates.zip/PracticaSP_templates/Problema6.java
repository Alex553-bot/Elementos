public class Problema6
{
	public int queNocheLaDeAnoche(ArbolBin<Integer> arbol, int mesaInfectada) {
		// completar este metodo
	}
}