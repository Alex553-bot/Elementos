public class Problema5
{
	public int[] rachaExitosa(int[] ar) {
		// completar este metodo
	}
}