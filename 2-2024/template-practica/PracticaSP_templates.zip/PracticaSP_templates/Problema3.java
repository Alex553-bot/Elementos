public class Problema3
{
	public int[] negativosPorVentana(int n, int k, int[] arreglo){
		// completar este metodo
	}
}