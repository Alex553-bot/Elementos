public class Problema1 
{
	public static int[] solve(Arbol<Integer> redAmistades) {
		// completar este metodo
	}
}