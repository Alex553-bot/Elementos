public class Problema4
{
	public int[] solve(int n, char q[], int v[]) {
		// completar este metodo
	}
}